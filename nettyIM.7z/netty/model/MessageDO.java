package com.domain.goodjob.netty.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageDO {
    private String msg;//文本信息
    private String state;//状态信息
    private String cmd;//1.绑定上线 2.下线 3.单聊 4.群聊
    private String from;//用户ID
    private String accept;//接受ID
    private String group;//组ID

    public MessageDO(String state, String cmd,String msg) {
        this.state = state;
        this.cmd = cmd;
        this.msg = msg;

    }

    public MessageDO(String state, String cmd, String from, String accept,String msg) {
        this.state = state;
        this.cmd = cmd;
        this.from = from;
        this.accept = accept;
        this.msg = msg;
    }
}
