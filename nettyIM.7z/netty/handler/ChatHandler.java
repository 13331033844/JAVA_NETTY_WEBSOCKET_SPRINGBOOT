package com.domain.goodjob.netty.handler;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.domain.goodjob.common.returnbean.ReturnBean;
import com.domain.goodjob.common.utils.GeodesyKit;
import com.domain.goodjob.common.utils.SecurityKit;
import com.domain.goodjob.instantmessagemodule.model.entity.ChatContent;
import com.domain.goodjob.instantmessagemodule.model.entity.ChatDetailContent;
import com.domain.goodjob.instantmessagemodule.service.impl.ChatServiceImpl;
import com.domain.goodjob.netty.model.MessageDO;
import com.domain.goodjob.netty.utils.BiDirectionHashMap;
import com.domain.goodjob.netty.utils.ChannelPool;
import com.domain.goodjob.recruitment.mapper.BcRecruitmentInformationMapper;
import com.domain.goodjob.recruitment.mapper.RecruitmentInformationMapper;
import com.domain.goodjob.recruitment.model.dto.RecruitmentInformationDTO;
import com.domain.goodjob.recruitment.model.entity.RecruitmentInformationModel;
import com.domain.goodjob.usermanagemodule.mapper.BcJobSeekersMapper;
import com.domain.goodjob.usermanagemodule.mapper.JobSeekersMapper;
import com.domain.goodjob.usermanagemodule.model.entity.JobSeekersModel;
import com.domain.goodjob.usermanagemodule.model.vo.JobSeekersBcHomeShowModelVO;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * 聊天的ehandler
 * TextWebSocketFrame  用于为websockt处理文本的对象
 * @author asus
 *
 */
public class ChatHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

    //用于记录和管理所有客户端的channel
    private static BiDirectionHashMap<Long, Channel> bHM = ChannelPool.biDirectionHashMap;

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) {
        try {
        //信息对象
        JSONObject jsonObject = JSONUtil.parseObj(msg.text());
        MessageDO messageDO = JSONUtil.toBean(jsonObject, MessageDO.class);
        //当前channel
        Channel channel = ctx.channel();

        if(null!= messageDO) {
            //web端登录先默认来一条信息，把channel插入hashmap里
            if("BIND".equals(messageDO.getCmd())){
                //发信人id和发信人通道存入bhm
                System.out.println(messageDO.getFrom());
                Long id = Long.parseLong(messageDO.getFrom());
                if (bHM.containsKey(id)){
                    //重复登录给原客户端通知，客户端主动断线
                    messageSend(bHM.getByKey(id),new MessageDO("重复登录","LOGINOUT",messageDO.getMsg()));
                    //bHM.removeByKey(id);
                }
                bHM.put(id, channel);
                //freshTime(channel);
                //连接成功给反一条
                messageSend(channel,new MessageDO("连接成功","ONLINE",messageDO.getMsg()));
                System.out.println(ChannelPool.biDirectionHashMap);

            }else if("SINGLE".equals(messageDO.getCmd())) {
                //收件人id
                Long id = Long.parseLong(messageDO.getAccept());
                messageDO = DoMessage(messageDO, 0);
                //收件人是否有channel
                if (bHM.containsKey(id)) {
                    Channel acceptChannel = bHM.getByKey(id);
                    //发送给收件人
                    messageSend(acceptChannel, messageDO);
                    //反馈给发送人
                    messageDO = DoMessage(messageDO, 1);
                    messageSend(channel,new MessageDO("发送成功","REPLY", messageDO.getFrom(), messageDO.getAccept(),messageDO.getMsg()));
                }else{
                    messageDO = DoMessage(messageDO, 1);
                    messageSend(channel,new MessageDO("对方不在线","REPLY", messageDO.getFrom(), messageDO.getAccept(),messageDO.getMsg()));
                }
                return;

            }else if("GROUP".equals(messageDO.getCmd())) {
                //循环队列里所有的channel
                Iterator<Map.Entry<Long, Channel>> entries  = bHM.getK2v().entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    Channel client = (Channel) entry.getValue();
                    messageSend(client, messageDO);
                }
            }else if("HEARTBEAT".equals(messageDO.getCmd())) {
                //messageSend(channel,new messageDO("心跳检测","HEARTBEAT"));
                //System.out.println(messageDO);
            }else {
                messageSend(channel,new MessageDO("未识别的命令","ERROR",messageDO.getMsg()));
            }
        }


        }catch (Exception e){
            e.printStackTrace();
        }



    }

    /**
     *  专门用来发送给客户端信息的方法，这里面之后要交给MQ处理
     * @param channel 发送通道
     * @param msg 发送的Message对象
     */
    private void messageSend(Channel channel, MessageDO msg){
        String str = JSONUtil.toJsonStr(msg);
        channel.writeAndFlush(new TextWebSocketFrame(str));
    }


    //客户端创建的时候触发，
    // 当客户端连接上服务端之后，
    // 就可以获取该channel，然后放到MyChannelHandlerMap中进行统一管理
    // 这段放在BIND里处理了，连接websocket同时发送一条信息过来。
    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        System.out.println("有人来了，channelID是："+ctx.channel().id().asShortText());
    }

    //客户端销毁的时候触发，
    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        //当handlerRemoved 被触发时候，MyChannelHandlerMap中移除当前channel
        bHM.removeByValue(ctx.channel());
        System.out.println("客户端断开，channelID是：" +ctx.channel().id().asShortText());
        System.out.println(ChannelPool.biDirectionHashMap);

    }

    private void freshTime (Channel channel) {
        if (ChannelPool.biDirectionHashMap.containsValue(channel)) {
            long id = ChannelPool.biDirectionHashMap.getByValue(channel);
            ChannelPool.lastUpdate.put(id, new Date());
        }
    }

    private MessageDO DoMessage (MessageDO messageDO,int right) {
        JSONObject json;
        net.sf.json.JSONObject jo = net.sf.json.JSONObject.fromObject(messageDO.getMsg());
        HashMap<String, String> hashMap = (HashMap) net.sf.json.JSONObject.toBean(jo, HashMap.class);
        ChatServiceImpl chatServiceImpl = (ChatServiceImpl) SpringUtil.getBean("chatServiceImpl");

        //加right
        hashMap.put("right", Convert.toStr(right));

        if(right == 1){
            //保存msg
            json = new JSONObject(hashMap);
            ChatContent chatContent = JSONUtil.toBean(Convert.toStr(json), ChatContent.class);
            boolean save = chatServiceImpl.save(chatContent);
        }else {
            //加头像
            String headUserID = hashMap.get("chatSendBy");
            HashMap<String, String> head = chatServiceImpl.getHead(Long.parseLong(headUserID));
            hashMap.put("name", head.get("name"));
            hashMap.put("user_type", head.get("user_type"));
            hashMap.put("headPath", head.get("head_path"));
            //加简历
            if ((Integer) jo.get("messageType") == 4) {
                BcJobSeekersMapper bcJobSeekersMapper = (BcJobSeekersMapper) SpringUtil.getBean("bcJobSeekersMapper");
                HashMap<String, String> ujs = bcJobSeekersMapper.getUjs(Long.parseLong(headUserID));
                ujs.put("post_type", bcJobSeekersMapper.getPostType(StrUtil.strip(Convert.toStr(ujs.get("post_type")), ",")));
                ujs.put("id", Convert.toStr(ujs.get("id")));
//                hashMap.put("jl", net.sf.json.JSONObject.fromObject(ujs).toString());
                hashMap.put("messageContent", net.sf.json.JSONObject.fromObject(ujs).toString());
            }

            //加岗位
            if ((Integer) jo.get("messageType") == 5) {
                BcRecruitmentInformationMapper bcRecruitmentInformationMapper = (BcRecruitmentInformationMapper) SpringUtil.getBean("bcRecruitmentInformationMapper");
                HashMap<String, String> gw = bcRecruitmentInformationMapper.getRi(Long.parseLong(Convert.toStr(jo.get("messageContent"))));
                DateTime dateTime = new DateTime(Convert.toStr(gw.get("create_time")), DatePattern.NORM_DATETIME_FORMAT);
                String s = DateUtil.formatDate(dateTime);
                gw.put("create_time", s);
                gw.put("id", Convert.toStr(gw.get("id")));
//                hashMap.put("gw", net.sf.json.JSONObject.fromObject(gw).toString());
                hashMap.put("messageContent", net.sf.json.JSONObject.fromObject(gw).toString());
            }
            json = new JSONObject(hashMap);
        }
        //存回
        messageDO.setMsg(Convert.toStr(json));

        return messageDO;
    }


    public JobSeekersModel listHandle(JobSeekersModel jobSeekersModel) {
        if(jobSeekersModel.getAge() != null){
        }

        return jobSeekersModel;
    }

    public RecruitmentInformationDTO listHandle(RecruitmentInformationDTO messageContent) {
        return messageContent;
    }


}